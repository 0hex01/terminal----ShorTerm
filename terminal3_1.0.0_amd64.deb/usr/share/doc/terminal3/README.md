# Terminal3

A modern, feature-rich terminal emulator built with GTK3 and VTE, featuring transparency settings, split panes, drag-and-drop support, color-coded text, and integrated authentication.

🔐 **Authentication**: [https://auth.qodo.aigo](https://auth.qodo.aigo)  
🎨 **Icon**: terminal.jpg

## ✨ Features

### 🎨 Color-Coded Text
- **Light Blue**: Program output and system messages
- **Light Lime Green**: User input and prompts
- **Automatic Color Detection**: Different colors for different types of text

### 🪟 Transparency Settings
- **11 Transparency Levels**: 0%, 10%, 20%, 30%, 40%, 50%, 60%, 70%, 80%, 90%, 100%
- **Context Menu Access**: Right-click → Transparency → Choose level
- **Real-time Updates**: Changes apply immediately to all panes

### ⌨️ Split Pane System
- **Recursive Splitting**: Split any focused pane horizontally or vertically
- **Unlimited Nesting**: Create complex layouts with multiple terminals
- **Focus Management**: Click on any pane to focus it, then split it further
- **Independent Terminals**: Each pane runs its own shell session

### 📁 Drag & Drop Support
- **Clean File Paths**: Drag files into terminal to get clean filepath output
- **No Extra Characters**: Just the pure file path, no formatting
- **Multiple Files**: Support for dropping multiple files at once

### 📜 Command History & Navigation
- **Arrow Key Navigation**: Use Up/Down arrows to browse through command history
- **✅ Fully Editable History**: History commands support full editing (backspace, delete, typing)
- **Persistent History**: Commands saved to `~/.terminal3_history` across sessions
- **Pre-loaded Test Commands**: Includes sample commands for immediate testing

### 💬 Special Commands
- **"nice terminal"**: Type this command to get a "thank you" response
- **"auth"**: Display the authentication URL
- **"qodo auth"**: Display the authentication URL
- **"terminal3 auth"**: Display the authentication URL
- **Automatic Prompt**: New prompt appears after special command responses
- **Global Commands**: Full PATH support for running system commands (ls, cd, vim, etc.)
- **Login Shell**: Starts as login shell with complete environment

### 🔧 Text Selection & Clipboard
- **Full Text Selection**: Click and drag to select text
- **Copy/Paste Support**: Standard clipboard operations
- **Select All**: Select entire terminal content

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Shift+C` | Copy selected text |
| `Ctrl+Shift+V` | Paste from clipboard |
| `Ctrl+Shift+A` | Select all text |
| `Ctrl+Shift+H` | Split current pane horizontally |
| `Ctrl+Shift+E` | Split current pane vertically |
| `Ctrl+Q` | Quit application |
| `Right-click` | Show context menu |
| `Up Arrow` | Navigate to previous command in history |
| `Down Arrow` | Navigate to next command in history |

## 🖱️ Context Menu

Right-click anywhere in the terminal to access:

- **Copy**: Copy selected text to clipboard
- **Paste**: Paste from clipboard
- **Select All**: Select all text in current pane
- **Split Horizontal**: Split current pane side-by-side
- **Split Vertical**: Split current pane top-bottom
- **Transparency**: Choose transparency level (0% to 100%)

## 🚀 Getting Started

### 📦 Installation (Debian/Ubuntu)

#### Method 1: Debian Package (Recommended)
```bash
# Build and install .deb package
./build-deb.sh
sudo dpkg -i ../terminal3_*.deb
```

#### Method 2: Direct Installation
```bash
# Install directly to system
./install.sh
```

#### Method 3: Development Build
```bash
# Build for development/testing
./build.sh
./run.sh
```

### Prerequisites (for building from source)
- GTK3 development libraries (`libgtk-3-dev`)
- VTE terminal widget library (`libvte-2.91-dev`)
- CMake 3.10 or higher
- C++17 compatible compiler
- pkg-config

### Running
```bash
# After installation:
terminal3

# Or from applications menu:
# Search for "Terminal3"
```

## 🎯 Usage Examples

### Basic Usage
1. **Start Terminal3**: Run `./run.sh`
2. **Use as Normal Terminal**: Type commands, run programs
3. **Right-click**: Access context menu for additional features

### Split Panes
1. **Focus a Pane**: Click on the terminal pane you want to split
2. **Split Horizontally**: Press `Ctrl+Shift+H` or right-click → Split Horizontal
3. **Split Vertically**: Press `Ctrl+Shift+E` or right-click → Split Vertical
4. **Continue Splitting**: Focus any pane and split it further

### Transparency
1. **Right-click**: Anywhere in the terminal
2. **Select Transparency**: Choose from 0% (opaque) to 100% (transparent)
3. **Immediate Effect**: All panes update instantly

### Drag & Drop
1. **Open File Manager**: Navigate to files you want to reference
2. **Drag File**: Drag any file into the terminal window
3. **Get Path**: Clean file path appears in the terminal

### Special Commands
1. **Type Command**: Enter `nice terminal` in any terminal pane
2. **Get Response**: See "thank you" message in light blue
3. **Continue**: New prompt appears automatically

## 🔧 Technical Details

### Architecture
- **Object-Oriented Design**: Clean C++ classes for different components
- **Recursive Split System**: Efficient tree structure for pane management
- **Event-Driven**: GTK signal-based event handling
- **Memory Safe**: Smart pointers and RAII principles

### Color System
- **ANSI Color Codes**: Uses standard terminal color sequences
- **Custom Palette**: 16-color palette with light blue and lime green
- **Automatic Detection**: Different colors for input vs output

### Transparency Implementation
- **Window Opacity**: GTK window-level transparency
- **Background Alpha**: VTE terminal background transparency
- **Composite Effects**: Proper alpha blending with desktop

## 🐛 Troubleshooting

### Build Issues
- **Missing GTK3**: Install `libgtk-3-dev` or equivalent
- **Missing VTE**: Install `libvte-2.91-dev` or equivalent
- **CMake Errors**: Ensure CMake 3.10+ is installed

### Runtime Issues
- **No Transparency**: Check if compositor is running
- **Split Not Working**: Ensure terminal pane is focused first
- **Colors Wrong**: Check terminal supports 256 colors

## 📝 License

This project is open source. Feel free to modify and distribute.

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Additional color themes
- More transparency effects
- Tab support
- Configuration file support
- Additional keyboard shortcuts

---

**Terminal3** - A modern terminal emulator with transparency, split panes, and color-coded text.